# Workspace

## Overview
Automobile Service Management — a Django + PostgreSQL full-stack web application for car/bike service workshops. Covers customer & vehicle records, inspection-based job cards, QR-coded inventory, GST billing with manual charges, and renewal reminders.

## Stack
- **Language**: Python 3.11
- **Framework**: Django 5
- **Database**: PostgreSQL (Replit-managed, via `DATABASE_URL`)
- **Static files**: WhiteNoise
- **QR codes**: `qrcode` + Pillow; client-side scan via `html5-qrcode`
- **Forms**: `django-widget-tweaks`

## Apps
- `core` — dashboard + seed command
- `customers` — Customer & Vehicle, quick-registration flow
- `inventory` — Part / Supplier / StockMovement, auto QR generation, scan endpoint
- `jobcards` — JobCard + JobCardPart, status workflow, parts deduction
- `billing` — Invoice + ManualCharge, GST recalc, printable invoice
- `reminders` — Service / Insurance / RC / Pollution reminders, auto-scheduled

## Project Layout
```
django_app/
  autoservice/   # settings, urls, wsgi
  core/ customers/ inventory/ jobcards/ billing/ reminders/
  templates/     # base + per-app
  static/css/    # app.css
```

## Run
- Workflow: `Django` → `cd django_app && PGSSLMODE=disable python manage.py runserver 0.0.0.0:5000 --insecure`
- DB migrations: `cd django_app && PGSSLMODE=disable python manage.py migrate`
- Seed sample data + admin user: `python manage.py seed` (admin / admin123)

## Notes
- `PGSSLMODE=disable` because Replit Postgres dev doesn't accept SSL.
- GST rate, shop name/address/phone/GSTIN configurable via env vars.
- Reminder send action only marks status; integrate Twilio/SMTP in `reminders/views.py:send` for real delivery.
