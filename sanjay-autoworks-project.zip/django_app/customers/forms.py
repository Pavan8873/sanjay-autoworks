from django import forms
from .models import Customer, Vehicle


class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = ["name", "phone", "email", "address", "gstin"]


class VehicleForm(forms.ModelForm):
    class Meta:
        model = Vehicle
        fields = [
            "vehicle_type", "registration_number", "make", "model", "color", "year",
            "engine_number", "chassis_number", "odometer",
            "insurance_expiry", "pollution_expiry", "rc_expiry",
        ]
        widgets = {
            "insurance_expiry": forms.DateInput(attrs={"type": "date"}),
            "pollution_expiry": forms.DateInput(attrs={"type": "date"}),
            "rc_expiry": forms.DateInput(attrs={"type": "date"}),
        }


class QuickRegisterForm(forms.Form):
    name = forms.CharField(max_length=200)
    phone = forms.CharField(max_length=20)
    email = forms.EmailField(required=False)
    address = forms.CharField(widget=forms.Textarea(attrs={"rows": 2}), required=False)
    gstin = forms.CharField(max_length=20, required=False, label="GSTIN (optional)")

    vehicle_type = forms.ChoiceField(choices=Vehicle.VEHICLE_TYPES)
    registration_number = forms.CharField(max_length=20)
    make = forms.CharField(max_length=80)
    model = forms.CharField(max_length=80)
    color = forms.CharField(max_length=40, required=False)
    year = forms.IntegerField(required=False)
    odometer = forms.IntegerField(required=False, initial=0)
    inspection_notes = forms.CharField(widget=forms.Textarea(attrs={"rows": 3}), required=False, label="Inspection Notes / Issues")
