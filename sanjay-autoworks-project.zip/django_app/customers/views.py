from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from .forms import CustomerForm, VehicleForm, QuickRegisterForm
from .models import Customer, Vehicle
from jobcards.models import JobCard


@login_required
def api_lookup_phone(request):
    phone = request.GET.get("phone", "").strip()
    if len(phone) < 4:
        return JsonResponse({"found": False})
    c = Customer.objects.filter(phone=phone).first() or Customer.objects.filter(phone__icontains=phone).first()
    if not c:
        return JsonResponse({"found": False})
    return JsonResponse({
        "found": True,
        "id": c.id,
        "name": c.name, "email": c.email, "address": c.address, "gstin": c.gstin,
        "vehicles": [
            {"id": v.id, "reg": v.registration_number, "make": v.make, "model": v.model,
             "type": v.vehicle_type, "color": v.color, "year": v.year, "odometer": v.odometer}
            for v in c.vehicles.all()
        ],
    })


@login_required
def api_lookup_vehicle(request):
    reg = request.GET.get("reg", "").strip().upper()
    if len(reg) < 4:
        return JsonResponse({"found": False})
    v = Vehicle.objects.filter(registration_number=reg).first()
    if not v:
        return JsonResponse({"found": False})
    return JsonResponse({
        "found": True, "id": v.id,
        "reg": v.registration_number, "make": v.make, "model": v.model,
        "type": v.vehicle_type, "color": v.color, "year": v.year, "odometer": v.odometer,
        "customer": {"id": v.customer.id, "name": v.customer.name, "phone": v.customer.phone,
                     "email": v.customer.email, "address": v.customer.address, "gstin": v.customer.gstin},
    })


@login_required
def list_customers(request):
    q = request.GET.get("q", "").strip()
    customers = Customer.objects.all().order_by("-created_at")
    if q:
        customers = customers.filter(Q(name__icontains=q) | Q(phone__icontains=q) | Q(email__icontains=q) | Q(vehicles__registration_number__icontains=q)).distinct()
    return render(request, "customers/list.html", {"customers": customers, "q": q})


@login_required
def quick_register(request):
    if request.method == "POST":
        form = QuickRegisterForm(request.POST)
        if form.is_valid():
            d = form.cleaned_data
            customer, _ = Customer.objects.get_or_create(
                phone=d["phone"],
                defaults={"name": d["name"], "email": d.get("email", ""), "address": d.get("address", ""), "gstin": d.get("gstin", "")},
            )
            vehicle, _ = Vehicle.objects.get_or_create(
                registration_number=d["registration_number"].upper(),
                defaults={
                    "customer": customer,
                    "vehicle_type": d["vehicle_type"],
                    "make": d["make"],
                    "model": d["model"],
                    "color": d.get("color", ""),
                    "year": d.get("year"),
                    "odometer": d.get("odometer") or 0,
                },
            )
            jc = JobCard.objects.create(
                customer=customer,
                vehicle=vehicle,
                inspection_notes=d.get("inspection_notes", ""),
                odometer_in=d.get("odometer") or 0,
            )
            messages.success(request, f"Customer registered and Job Card {jc.job_number} created.")
            return redirect("jobcards:detail", pk=jc.pk)
    else:
        form = QuickRegisterForm()
    return render(request, "customers/quick_register.html", {"form": form})


@login_required
def detail(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    return render(request, "customers/detail.html", {
        "customer": customer,
        "vehicles": customer.vehicles.all(),
        "jobcards": customer.jobcards.all().order_by("-created_at"),
    })


@login_required
def edit(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == "POST":
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            messages.success(request, "Customer updated.")
            return redirect("customers:detail", pk=pk)
    else:
        form = CustomerForm(instance=customer)
    return render(request, "customers/form.html", {"form": form, "title": "Edit Customer"})


@login_required
def add_vehicle(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == "POST":
        form = VehicleForm(request.POST)
        if form.is_valid():
            v = form.save(commit=False)
            v.customer = customer
            v.registration_number = v.registration_number.upper()
            v.save()
            messages.success(request, "Vehicle added.")
            return redirect("customers:detail", pk=pk)
    else:
        form = VehicleForm()
    return render(request, "customers/form.html", {"form": form, "title": f"Add Vehicle for {customer.name}"})


@login_required
def vehicle_detail(request, pk):
    vehicle = get_object_or_404(Vehicle, pk=pk)
    return render(request, "customers/vehicle_detail.html", {
        "vehicle": vehicle,
        "jobcards": vehicle.jobcards.all().order_by("-created_at"),
        "reminders": vehicle.reminders.all(),
    })


@login_required
def edit_vehicle(request, pk):
    vehicle = get_object_or_404(Vehicle, pk=pk)
    if request.method == "POST":
        form = VehicleForm(request.POST, instance=vehicle)
        if form.is_valid():
            form.save()
            messages.success(request, "Vehicle updated.")
            return redirect("customers:vehicle_detail", pk=pk)
    else:
        form = VehicleForm(instance=vehicle)
    return render(request, "customers/form.html", {"form": form, "title": "Edit Vehicle"})
