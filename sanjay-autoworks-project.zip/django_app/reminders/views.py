from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .models import Reminder
from .forms import ReminderForm
from customers.models import Vehicle


@login_required
def list_reminders(request):
    status = request.GET.get("status", "pending")
    reminders = Reminder.objects.select_related("vehicle__customer").order_by("due_date")
    if status:
        reminders = reminders.filter(status=status)
    return render(request, "reminders/list.html", {"reminders": reminders, "status": status})


@login_required
def send(request, pk):
    r = get_object_or_404(Reminder, pk=pk)
    # In production this would call Email/SMS/WhatsApp providers.
    r.status = "sent"
    r.sent_at = timezone.now()
    r.save()
    messages.success(request, f"Reminder sent via {r.get_channel_display()}.")
    return redirect("reminders:list")


@login_required
def dismiss(request, pk):
    r = get_object_or_404(Reminder, pk=pk)
    r.status = "dismissed"
    r.save()
    return redirect("reminders:list")


@login_required
def create(request, vehicle_id):
    vehicle = get_object_or_404(Vehicle, pk=vehicle_id)
    if request.method == "POST":
        form = ReminderForm(request.POST)
        if form.is_valid():
            r = form.save(commit=False)
            r.vehicle = vehicle
            r.save()
            return redirect("customers:vehicle_detail", pk=vehicle.pk)
    else:
        form = ReminderForm()
    return render(request, "reminders/form.html", {"form": form, "vehicle": vehicle})
