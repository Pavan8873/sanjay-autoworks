from django import forms
from .models import Reminder


class ReminderForm(forms.ModelForm):
    class Meta:
        model = Reminder
        fields = ["reminder_type", "due_date", "channel", "message"]
        widgets = {"due_date": forms.DateInput(attrs={"type": "date"})}
