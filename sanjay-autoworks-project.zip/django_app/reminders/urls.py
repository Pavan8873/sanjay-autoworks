from django.urls import path
from . import views

app_name = "reminders"

urlpatterns = [
    path("", views.list_reminders, name="list"),
    path("<int:pk>/send/", views.send, name="send"),
    path("<int:pk>/dismiss/", views.dismiss, name="dismiss"),
    path("new/<int:vehicle_id>/", views.create, name="new"),
]
