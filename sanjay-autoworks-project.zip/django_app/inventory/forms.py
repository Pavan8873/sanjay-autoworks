from django import forms
from .models import Part, Supplier, StockMovement


class PartForm(forms.ModelForm):
    class Meta:
        model = Part
        fields = ["sku", "name", "description", "category", "supplier", "unit_price", "stock", "reorder_level"]


class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ["name", "phone", "email", "address"]


class RestockForm(forms.Form):
    quantity = forms.IntegerField(min_value=1)
    note = forms.CharField(max_length=200, required=False)
