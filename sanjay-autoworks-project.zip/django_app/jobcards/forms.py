from django import forms
from .models import JobCard, JobCardPart


class JobCardForm(forms.ModelForm):
    class Meta:
        model = JobCard
        fields = ["customer", "vehicle", "mechanic", "odometer_in", "inspection_notes", "work_to_do", "status", "labor_hours", "labor_rate"]


class AddPartForm(forms.Form):
    sku = forms.CharField(max_length=60, required=False, label="Scan / Enter SKU")
    part_id = forms.IntegerField(required=False, widget=forms.HiddenInput)
    quantity = forms.IntegerField(min_value=1, initial=1)
