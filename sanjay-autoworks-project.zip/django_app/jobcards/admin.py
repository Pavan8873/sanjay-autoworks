from django.contrib import admin
from .models import JobCard, JobCardPart
admin.site.register(JobCard)
admin.site.register(JobCardPart)
