from datetime import date, timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from .forms import JobCardForm, AddPartForm
from .models import JobCard, JobCardPart
from django.db.models import Sum
from inventory.models import Part, StockMovement
from billing.models import Invoice
from reminders.models import Reminder


@login_required
def list_jobs(request):
    status = request.GET.get("status", "")
    jobs = JobCard.objects.select_related("customer", "vehicle").order_by("-created_at")
    if status:
        jobs = jobs.filter(status=status)
    return render(request, "jobcards/list.html", {"jobs": jobs, "status": status})


@login_required
def create(request):
    if request.method == "POST":
        form = JobCardForm(request.POST)
        if form.is_valid():
            jc = form.save()
            messages.success(request, f"Job Card {jc.job_number} created.")
            return redirect("jobcards:detail", pk=jc.pk)
    else:
        form = JobCardForm()
    return render(request, "jobcards/form.html", {"form": form, "title": "New Job Card"})


@login_required
def detail(request, pk):
    jc = get_object_or_404(JobCard, pk=pk)
    add_form = AddPartForm()
    popular = (Part.objects
               .annotate(used=Sum("jobcardpart__quantity"))
               .filter(stock__gt=0)
               .order_by("-used", "name")[:8])
    return render(request, "jobcards/detail.html", {
        "job": jc, "add_form": add_form, "popular_parts": popular,
    })


@login_required
def edit(request, pk):
    jc = get_object_or_404(JobCard, pk=pk)
    if request.method == "POST":
        form = JobCardForm(request.POST, instance=jc)
        if form.is_valid():
            form.save()
            return redirect("jobcards:detail", pk=pk)
    else:
        form = JobCardForm(instance=jc)
    return render(request, "jobcards/form.html", {"form": form, "title": f"Edit {jc.job_number}"})


@login_required
@transaction.atomic
def add_part(request, pk):
    jc = get_object_or_404(JobCard, pk=pk)
    form = AddPartForm(request.POST)
    if form.is_valid():
        part = None
        if form.cleaned_data.get("part_id"):
            part = Part.objects.filter(pk=form.cleaned_data["part_id"]).first()
        if not part and form.cleaned_data.get("sku"):
            part = Part.objects.filter(sku=form.cleaned_data["sku"]).first()
        if not part:
            messages.error(request, "Part not found. Check SKU/QR code.")
            return redirect("jobcards:detail", pk=pk)
        qty = form.cleaned_data["quantity"]
        if part.stock < qty:
            messages.error(request, f"Insufficient stock for {part.name}. Available: {part.stock}")
            return redirect("jobcards:detail", pk=pk)
        JobCardPart.objects.create(jobcard=jc, part=part, quantity=qty, unit_price=part.unit_price)
        part.stock -= qty
        part.save()
        StockMovement.objects.create(part=part, movement_type="out", quantity=qty, note=f"Used in {jc.job_number}")
        if jc.status == "open":
            jc.status = "in_progress"
            jc.save()
        messages.success(request, f"Added {qty} x {part.name}")
    return redirect("jobcards:detail", pk=pk)


@login_required
@transaction.atomic
def remove_part(request, pk, part_id):
    jc = get_object_or_404(JobCard, pk=pk)
    line = get_object_or_404(JobCardPart, pk=part_id, jobcard=jc)
    line.part.stock += line.quantity
    line.part.save()
    StockMovement.objects.create(part=line.part, movement_type="in", quantity=line.quantity, note=f"Reverted from {jc.job_number}")
    line.delete()
    messages.success(request, "Part removed and stock restored.")
    return redirect("jobcards:detail", pk=pk)


@login_required
@transaction.atomic
def complete(request, pk):
    jc = get_object_or_404(JobCard, pk=pk)
    jc.status = "completed"
    jc.completed_at = timezone.now()
    jc.save()

    invoice, created = Invoice.objects.get_or_create(jobcard=jc)
    invoice.recalculate()

    Reminder.objects.get_or_create(
        vehicle=jc.vehicle,
        reminder_type="service",
        due_date=date.today() + timedelta(days=365),
        defaults={"message": f"Annual service due (last service: {jc.job_number})"},
    )
    if jc.vehicle.insurance_expiry:
        Reminder.objects.get_or_create(
            vehicle=jc.vehicle, reminder_type="insurance",
            due_date=jc.vehicle.insurance_expiry - timedelta(days=15),
            defaults={"message": "Insurance renewal coming up"},
        )
    if jc.vehicle.pollution_expiry:
        Reminder.objects.get_or_create(
            vehicle=jc.vehicle, reminder_type="pollution",
            due_date=jc.vehicle.pollution_expiry - timedelta(days=15),
            defaults={"message": "Pollution certificate renewal coming up"},
        )
    if jc.vehicle.rc_expiry:
        Reminder.objects.get_or_create(
            vehicle=jc.vehicle, reminder_type="rc",
            due_date=jc.vehicle.rc_expiry - timedelta(days=30),
            defaults={"message": "RC renewal coming up"},
        )
    messages.success(request, "Job marked complete. Invoice generated and reminders scheduled.")
    return redirect("billing:detail", pk=invoice.pk)
