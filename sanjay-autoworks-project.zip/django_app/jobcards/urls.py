from django.urls import path
from . import views

app_name = "jobcards"

urlpatterns = [
    path("", views.list_jobs, name="list"),
    path("new/", views.create, name="new"),
    path("<int:pk>/", views.detail, name="detail"),
    path("<int:pk>/edit/", views.edit, name="edit"),
    path("<int:pk>/add-part/", views.add_part, name="add_part"),
    path("<int:pk>/remove-part/<int:part_id>/", views.remove_part, name="remove_part"),
    path("<int:pk>/complete/", views.complete, name="complete"),
]
