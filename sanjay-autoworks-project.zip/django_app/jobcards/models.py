from django.db import models
from django.contrib.auth.models import User
from customers.models import Customer, Vehicle
from inventory.models import Part


class JobCard(models.Model):
    STATUS_CHOICES = [
        ("open", "Open"),
        ("in_progress", "In Progress"),
        ("completed", "Completed"),
        ("billed", "Billed"),
        ("cancelled", "Cancelled"),
    ]
    job_number = models.CharField(max_length=20, unique=True, blank=True)
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT, related_name="jobcards")
    vehicle = models.ForeignKey(Vehicle, on_delete=models.PROTECT, related_name="jobcards")
    mechanic = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL)
    odometer_in = models.PositiveIntegerField(null=True, blank=True)
    inspection_notes = models.TextField(blank=True, help_text="Issues observed during inspection")
    work_to_do = models.TextField(blank=True, help_text="List of works to be carried out")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="open")
    labor_hours = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    labor_rate = models.DecimalField(max_digits=8, decimal_places=2, default=400, help_text="Per hour")
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.job_number:
            super().save(*args, **kwargs)
            self.job_number = f"JC-{self.created_at.strftime('%Y%m')}-{self.pk:05d}"
            super().save(update_fields=["job_number"])
        else:
            super().save(*args, **kwargs)

    @property
    def parts_total(self):
        return sum((i.line_total for i in self.parts_used.all()), 0)

    @property
    def labor_total(self):
        return self.labor_hours * self.labor_rate

    def __str__(self):
        return self.job_number or f"JobCard #{self.pk}"


class JobCardPart(models.Model):
    jobcard = models.ForeignKey(JobCard, related_name="parts_used", on_delete=models.CASCADE)
    part = models.ForeignKey(Part, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField(default=1)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def line_total(self):
        return self.quantity * self.unit_price
