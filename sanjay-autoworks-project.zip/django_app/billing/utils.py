from decimal import Decimal

_ones = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen',
]
_tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety']


def _below_100(n):
    if n < 20:
        return _ones[n]
    return _tens[n // 10] + (' ' + _ones[n % 10] if n % 10 else '')


def _below_1000(n):
    if n < 100:
        return _below_100(n)
    return _ones[n // 100] + ' Hundred' + (' ' + _below_100(n % 100) if n % 100 else '')


def _convert(n):
    if n == 0:
        return 'Zero'
    parts = []
    if n >= 10000000:
        parts.append(_below_1000(n // 10000000) + ' Crore')
        n %= 10000000
    if n >= 100000:
        parts.append(_below_1000(n // 100000) + ' Lakh')
        n %= 100000
    if n >= 1000:
        parts.append(_below_1000(n // 1000) + ' Thousand')
        n %= 1000
    if n:
        parts.append(_below_1000(n))
    return ' '.join(parts)


def amount_in_words(amount):
    amount = Decimal(str(amount)).quantize(Decimal('0.01'))
    rupees = int(amount)
    paise = int(round((amount - rupees) * 100))
    result = _convert(rupees) + ' Rupees'
    if paise:
        result += ' and ' + _convert(paise) + ' Paise'
    return result + ' Only'
