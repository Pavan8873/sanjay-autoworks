from django import forms
from .models import ManualCharge, Invoice


class ManualChargeForm(forms.ModelForm):
    class Meta:
        model = ManualCharge
        fields = ["description", "amount"]


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Invoice
        fields = ["payment_method", "notes"]
