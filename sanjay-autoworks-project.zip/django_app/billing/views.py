from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .forms import ManualChargeForm, PaymentForm
from .models import Invoice, ManualCharge
from .utils import amount_in_words


@login_required
def list_invoices(request):
    status = request.GET.get("status", "")
    invoices = Invoice.objects.select_related("jobcard__customer", "jobcard__vehicle").order_by("-created_at")
    if status == "paid":
        invoices = invoices.filter(paid=True)
    elif status == "pending":
        invoices = invoices.filter(paid=False)
    return render(request, "billing/list.html", {"invoices": invoices, "status": status})


@login_required
def detail(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    invoice.recalculate()
    return render(request, "billing/detail.html", {
        "invoice": invoice,
        "charge_form": ManualChargeForm(),
        "payment_form": PaymentForm(instance=invoice),
        "presets": ManualCharge.PRESETS,
    })


@login_required
def add_charge(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    form = ManualChargeForm(request.POST)
    if form.is_valid():
        c = form.save(commit=False)
        c.invoice = invoice
        c.save()
        invoice.recalculate()
        messages.success(request, "Charge added.")
    return redirect("billing:detail", pk=pk)


@login_required
def remove_charge(request, pk, charge_id):
    invoice = get_object_or_404(Invoice, pk=pk)
    ManualCharge.objects.filter(pk=charge_id, invoice=invoice).delete()
    invoice.recalculate()
    return redirect("billing:detail", pk=pk)


@login_required
def mark_paid(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    if request.method == "POST":
        form = PaymentForm(request.POST, instance=invoice)
        if form.is_valid():
            inv = form.save(commit=False)
            inv.paid = True
            inv.save()
            inv.jobcard.status = "billed"
            inv.jobcard.save()
            messages.success(request, "Payment recorded.")
    return redirect("billing:detail", pk=pk)


@login_required
def print_invoice(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    invoice.recalculate()
    cgst_rate = invoice.gst_rate / 2
    cgst_amount = (invoice.gst_amount / 2).quantize(invoice.gst_amount)
    sgst_amount = invoice.gst_amount - cgst_amount
    total_qty = sum(p.quantity for p in invoice.jobcard.parts_used.all())
    if invoice.jobcard.labor_total:
        total_qty += 1
    total_qty += invoice.manual_charges.count()
    return render(request, "billing/print.html", {
        "invoice": invoice,
        "cgst_rate": cgst_rate,
        "cgst_amount": cgst_amount,
        "sgst_amount": sgst_amount,
        "total_qty": total_qty,
        "amount_in_words": amount_in_words(invoice.total),
        "tax_in_words": amount_in_words(invoice.gst_amount),
        "SHOP_NAME": settings.SHOP_NAME,
        "SHOP_ADDRESS": settings.SHOP_ADDRESS,
        "SHOP_PHONE": settings.SHOP_PHONE,
        "SHOP_EMAIL": getattr(settings, "SHOP_EMAIL", ""),
        "SHOP_GSTIN": settings.SHOP_GSTIN,
        "SHOP_STATE": getattr(settings, "SHOP_STATE", "Karnataka"),
        "SHOP_STATE_CODE": getattr(settings, "SHOP_STATE_CODE", "29"),
        "SHOP_JURISDICTION": getattr(settings, "SHOP_JURISDICTION", ""),
        "BANK_HOLDER_NAME": getattr(settings, "BANK_HOLDER_NAME", ""),
        "BANK_NAME": getattr(settings, "BANK_NAME", ""),
        "BANK_ACCOUNT": getattr(settings, "BANK_ACCOUNT", ""),
        "BANK_IFSC": getattr(settings, "BANK_IFSC", ""),
        "BANK_BRANCH": getattr(settings, "BANK_BRANCH", ""),
        "GST_RATE": settings.GST_RATE,
    })
