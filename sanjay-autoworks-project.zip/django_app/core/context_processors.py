from django.conf import settings


def app_settings(request):
    return {
        "SHOP_NAME": settings.SHOP_NAME,
        "SHOP_ADDRESS": settings.SHOP_ADDRESS,
        "SHOP_PHONE": settings.SHOP_PHONE,
        "SHOP_EMAIL": getattr(settings, "SHOP_EMAIL", ""),
        "SHOP_GSTIN": settings.SHOP_GSTIN,
        "SHOP_STATE": getattr(settings, "SHOP_STATE", "Karnataka"),
        "SHOP_STATE_CODE": getattr(settings, "SHOP_STATE_CODE", "29"),
        "SHOP_JURISDICTION": getattr(settings, "SHOP_JURISDICTION", ""),
        "BANK_HOLDER_NAME": getattr(settings, "BANK_HOLDER_NAME", ""),
        "BANK_NAME": getattr(settings, "BANK_NAME", ""),
        "BANK_ACCOUNT": getattr(settings, "BANK_ACCOUNT", ""),
        "BANK_IFSC": getattr(settings, "BANK_IFSC", ""),
        "BANK_BRANCH": getattr(settings, "BANK_BRANCH", ""),
        "GST_RATE": settings.GST_RATE,
    }
