from datetime import date, timedelta
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, F
from django.shortcuts import render

from customers.models import Customer, Vehicle
from jobcards.models import JobCard
from billing.models import Invoice
from inventory.models import Part
from reminders.models import Reminder


@login_required
def dashboard(request):
    today = date.today()
    upcoming = today + timedelta(days=30)

    open_jobs = (JobCard.objects.exclude(status__in=["billed", "cancelled"])
                 .select_related("customer", "vehicle").order_by("-created_at")[:8])
    pending_payments = (Invoice.objects.filter(paid=False)
                        .select_related("jobcard__customer", "jobcard__vehicle")[:8])
    low_stock = list(Part.objects.filter(stock__lte=F("reorder_level")).order_by("stock")[:8])
    upcoming_reminders = (Reminder.objects.filter(status="pending", due_date__lte=upcoming)
                          .select_related("vehicle__customer").order_by("due_date")[:8])

    stats = {
        "customers": Customer.objects.count(),
        "vehicles": Vehicle.objects.count(),
        "open_jobs": JobCard.objects.exclude(status__in=["billed", "cancelled"]).count(),
        "completed_today": JobCard.objects.filter(completed_at__date=today).count(),
        "revenue_month": Invoice.objects.filter(paid=True, created_at__year=today.year, created_at__month=today.month).aggregate(s=Sum("total"))["s"] or 0,
        "pending_amount": Invoice.objects.filter(paid=False).aggregate(s=Sum("total"))["s"] or 0,
        "parts_count": Part.objects.count(),
        "low_stock_count": Part.objects.filter(stock__lte=F("reorder_level")).count(),
    }

    # Revenue last 14 days (for chart)
    days = [(today - timedelta(days=i)) for i in range(13, -1, -1)]
    rev_map = {d: 0 for d in days}
    rows = (Invoice.objects.filter(paid=True, created_at__date__gte=days[0])
            .values("created_at__date").annotate(s=Sum("total")))
    for row in rows:
        d = row["created_at__date"]
        if d in rev_map:
            rev_map[d] = float(row["s"] or 0)
    revenue_series = {
        "labels": [d.strftime("%d %b") for d in days],
        "values": [rev_map[d] for d in days],
    }

    # Job status breakdown
    status_counts = dict(JobCard.objects.values_list("status").annotate(c=Count("id")).values_list("status", "c"))
    status_chart = {
        "labels": ["Open", "In Progress", "Completed", "Billed", "Cancelled"],
        "values": [status_counts.get(k, 0) for k in ["open", "in_progress", "completed", "billed", "cancelled"]],
    }

    return render(request, "core/dashboard.html", {
        "stats": stats,
        "open_jobs": open_jobs,
        "pending_payments": pending_payments,
        "low_stock": low_stock,
        "upcoming_reminders": upcoming_reminders,
        "revenue_series": revenue_series,
        "status_chart": status_chart,
    })
